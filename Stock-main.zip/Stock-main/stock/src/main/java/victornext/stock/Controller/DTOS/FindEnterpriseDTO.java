package victornext.stock.Controller.DTOS;

public record FindEnterpriseDTO(
        String name
) {

}
