package victornext.stock.Exceptions;

public class InvalidField extends RuntimeException {
    public InvalidField(String message) {
        super(message);
    }
}
