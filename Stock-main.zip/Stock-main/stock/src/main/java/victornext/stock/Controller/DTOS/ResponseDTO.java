package victornext.stock.Controller.DTOS;

public record ResponseDTO(
        String name,
        String token
) { }
