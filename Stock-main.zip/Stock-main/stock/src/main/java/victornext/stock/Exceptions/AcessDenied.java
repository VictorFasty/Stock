package victornext.stock.Exceptions;

public class AcessDenied extends RuntimeException {
    public AcessDenied(String message) {
        super(message);
    }
}
